#!/bin/sh
./jre/bin/java -classpath ".;lib;jre" -Xms64m -Xmx1024m -Dlog.dir=./logs  -jar dts-client-sidap.jar
