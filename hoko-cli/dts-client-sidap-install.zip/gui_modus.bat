cd %~dp0
"java" -Xms64m -Xmx1024m -Dlog.dir="%~dp0LogFiles" -jar dts-client-sidap.jar
