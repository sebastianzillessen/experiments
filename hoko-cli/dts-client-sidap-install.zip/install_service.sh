#!/bin/sh
java -cp `dirname $0`/dts-client-sidap.jar -Dlog.dir=/var/log/SiDAP com.unisys.ch.dts.client.InstallService
