#!/bin/sh
java -Xms64m -Xmx1024m -Dlog.dir=./logs -jar dts-client-sidap.jar
